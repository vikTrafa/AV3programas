package models;

public class Tecnico {
    
}
